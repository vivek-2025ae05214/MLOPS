import pytest
from pydantic import ValidationError
from src.heart_mlops.schema import PatientFeatures

def test_valid_payload():
    p=PatientFeatures(age=63,sex=1,cp=4,trestbps=145,chol=233,fbs=1,restecg=2,thalach=150,exang=0,oldpeak=2.3,slope=3,ca=0,thal=6)
    assert p.age == 63

def test_invalid_age():
    with pytest.raises(ValidationError):
        PatientFeatures(age=-1,sex=1,cp=4,trestbps=145,chol=233,fbs=1,restecg=2,thalach=150,exang=0,oldpeak=2.3,slope=3,ca=0,thal=6)
