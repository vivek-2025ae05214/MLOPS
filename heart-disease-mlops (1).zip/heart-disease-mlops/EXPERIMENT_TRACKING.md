# Experiment tracking

MLflow is configured with the experiment name `heart-disease-uci`. By default, runs are stored locally in `mlruns`; set `MLFLOW_TRACKING_URI` to use a shared tracking server.

Each candidate-model run records:
- dataset, model and lifecycle tags
- random seed, split ratio, CV folds, selection metric and imputation strategies
- best hyperparameters and best cross-validation ROC-AUC
- complete `GridSearchCV` results as CSV
- the fitted scikit-learn pipeline as an MLflow model
- inferred model signature and input example

The final-evaluation run records:
- selected model and decision threshold
- accuracy, precision, recall, F1 and ROC-AUC
- ROC and confusion-matrix plots
- model leaderboard and metrics JSON
- final pipeline as an MLflow model

Start the UI after training:

```bash
mlflow ui --backend-store-uri mlruns
```

For a shared environment, point `MLFLOW_TRACKING_URI` at an authenticated MLflow server and use an object store for artefacts.
