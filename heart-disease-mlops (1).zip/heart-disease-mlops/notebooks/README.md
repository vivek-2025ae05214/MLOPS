Run the scripted EDA for reproducibility: `python -m src.heart_mlops.eda`. A notebook may be added for narrative exploration, but production transformations remain in `src/`.
