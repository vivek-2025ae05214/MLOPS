# Heart Disease UCI: production-style MLOps project

Educational classifier using the UCI Heart Disease dataset. **Not a medical device and not for clinical decisions.**

## What is included
- reproducible UCI download and validation
- EDA report with histograms, class balance and correlation heatmap
- scikit-learn preprocessing with imputation, scaling and one-hot encoding
- Logistic Regression and Random Forest, stratified cross-validation and GridSearchCV
- MLflow experiment tracking
- model evaluation with accuracy, precision, recall, F1 and ROC-AUC
- FastAPI prediction service, Prometheus metrics and structured prediction logging
- Docker, Docker Compose, tests, linting and GitHub Actions CI

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate              # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
make data
make eda
make train
make test
make api
```
Open Swagger UI at `http://localhost:8000/docs`, metrics at `http://localhost:8000/metrics`, and MLflow with `mlflow ui --backend-store-uri mlruns`.


## 3. Experiment Tracking [5 marks]
MLflow logs every candidate run and the final evaluation. Parameters, cross-validation and test metrics, complete tuning results, trained pipelines, model signatures, input examples, ROC plots and confusion-matrix plots are retained. See `EXPERIMENT_TRACKING.md`.

## 4. Model Packaging & Reproducibility [7 marks]
The selected preprocessing-plus-model pipeline is exported as `artifacts/model.joblib` and as an MLflow model. The repository includes a clean `requirements.txt`, a fixed seed, deterministic data acquisition by UCI dataset ID and instructions for generating an exact `requirements-lock.txt`. See `REPRODUCIBILITY.md`.

## Docker
Train first so `artifacts/model.joblib` exists, then:
```bash
docker compose up --build
```

## Example request
```bash
curl -X POST http://localhost:8000/predict \
  -H 'Content-Type: application/json' \
  -d '{"age":63,"sex":1,"cp":4,"trestbps":145,"chol":233,"fbs":1,"restecg":2,"thalach":150,"exang":0,"oldpeak":2.3,"slope":3,"ca":0,"thal":6}'
```

## Repository layout
```text
src/heart_mlops/       acquisition, EDA, training, inference, API
configs/               modelling configuration
notebooks/             optional notebook placeholder
reports/figures/       generated EDA/model plots
artifacts/              model, metrics and reference data
tests/                  unit/API tests
.github/workflows/      CI pipeline
```

## Model-selection policy
The training script tunes both candidates using 5-fold stratified CV and selects the model with the highest mean ROC-AUC. The untouched 20% test split is then used once for final metrics. Recall is reported prominently because false negatives are undesirable in a risk-screening demonstration, but the selection rule remains ROC-AUC to compare ranking quality across thresholds.

## Reproducibility
Random seed is fixed at 42. Data is downloaded from UCI dataset ID 45. Package versions are bounded in `requirements.txt`; for exact environment locking, run `pip freeze > requirements-lock.txt` after installation.

## Deliverables generated
- `reports/eda_summary.json`
- `reports/figures/*.png`
- `artifacts/model.joblib`
- `artifacts/metrics.json`
- `artifacts/cv_results.csv`
- `artifacts/training_reference.csv`

## Cloud deployment pattern
Push the container to Azure Container Registry, Amazon ECR or Google Artifact Registry, then deploy to Azure Container Apps, AWS ECS/Fargate or Google Cloud Run. Supply `MODEL_PATH` as an environment variable and mount or bake in a versioned model artefact. For a real production system, use a model registry, TLS, authentication, encrypted logs, retention controls, alerting and a clinical validation/governance process.
