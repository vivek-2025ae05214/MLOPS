# Model packaging and reproducibility

The final pipeline is saved in two reusable forms:

1. `artifacts/model.joblib` for direct loading by the FastAPI service.
2. The MLflow model logged under the `final_model_evaluation` run, including its signature and input example.

The serialised object contains preprocessing and the estimator together, so inference receives the same imputation, encoding and scaling used during training.

## Recreate the result

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m src.heart_mlops.data
python -m src.heart_mlops.eda
python -m src.heart_mlops.train
pytest -q
```

The split and cross-validation seed are fixed at 42. The dataset is fetched by UCI dataset ID 45. `requirements.txt` defines compatible dependency ranges. To capture the exact resolved environment used for submission, run:

```bash
pip freeze --all > requirements-lock.txt
```

Commit `requirements-lock.txt` with the submission and install it with `pip install -r requirements-lock.txt` when exact package reproduction is required.

Do not load joblib or pickle files from untrusted sources because Python serialisation may execute code during loading.
