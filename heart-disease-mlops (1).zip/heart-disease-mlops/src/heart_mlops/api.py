from pathlib import Path
import json, os, time, uuid
import joblib, pandas as pd
from fastapi import FastAPI, HTTPException, Response
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from .schema import PatientFeatures, Prediction

app=FastAPI(title="Heart Disease Risk Classifier",version="1.0.0")
REQ=Counter("prediction_requests_total","Prediction requests",["status"])
LAT=Histogram("prediction_latency_seconds","Prediction latency")
MODEL=None

def get_model():
    global MODEL
    if MODEL is None:
        path=Path(os.getenv("MODEL_PATH","artifacts/model.joblib"))
        if not path.exists(): raise HTTPException(503,"Model artefact missing. Run training first.")
        MODEL=joblib.load(path)
    return MODEL

@app.get("/health")
def health(): return {"status":"ok","model_loaded":MODEL is not None}

@app.get("/metrics")
def metrics(): return Response(generate_latest(),media_type=CONTENT_TYPE_LATEST)

@app.post("/predict",response_model=Prediction)
def predict(payload: PatientFeatures):
    started=time.perf_counter()
    try:
        model=get_model(); frame=pd.DataFrame([payload.model_dump()])
        probability=float(model.predict_proba(frame)[0,1]); predicted=int(probability>=.5)
        Path("logs").mkdir(exist_ok=True)
        event={"request_id":str(uuid.uuid4()),"features":payload.model_dump(),"probability":probability,"predicted_class":predicted}
        with Path("logs/predictions.jsonl").open("a") as f: f.write(json.dumps(event)+"\n")
        REQ.labels("success").inc(); return Prediction(predicted_class=predicted,probability=probability,model_version="1.0.0")
    except HTTPException:
        REQ.labels("error").inc(); raise
    finally: LAT.observe(time.perf_counter()-started)
