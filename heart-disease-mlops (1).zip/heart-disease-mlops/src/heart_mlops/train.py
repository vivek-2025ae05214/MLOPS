from pathlib import Path
import json
import os

import joblib
import matplotlib.pyplot as plt
import mlflow
import mlflow.sklearn
import pandas as pd
from mlflow.models import infer_signature
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    RocCurveDisplay,
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .data import RAW, download

SEED = 42
CATEGORICAL = ["sex", "cp", "fbs", "restecg", "exang", "slope", "ca", "thal"]
NUMERIC = ["age", "trestbps", "chol", "thalach", "oldpeak"]


def preprocessing():
    numeric = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    return ColumnTransformer([
        ("numeric", numeric, NUMERIC),
        ("categorical", categorical, CATEGORICAL),
    ])


def calculate_metrics(y_true, predictions, probabilities):
    return {
        "accuracy": accuracy_score(y_true, predictions),
        "precision": precision_score(y_true, predictions, zero_division=0),
        "recall": recall_score(y_true, predictions, zero_division=0),
        "f1": f1_score(y_true, predictions, zero_division=0),
        "roc_auc": roc_auc_score(y_true, probabilities),
    }


def save_evaluation_plots(y_true, predictions, probabilities, output_dir):
    output_dir.mkdir(parents=True, exist_ok=True)
    roc_path = output_dir / "roc_curve.png"
    cm_path = output_dir / "confusion_matrix.png"

    RocCurveDisplay.from_predictions(y_true, probabilities)
    plt.tight_layout()
    plt.savefig(roc_path, dpi=160)
    plt.close()

    ConfusionMatrixDisplay.from_predictions(y_true, predictions)
    plt.tight_layout()
    plt.savefig(cm_path, dpi=160)
    plt.close()
    return roc_path, cm_path


def main():
    df = pd.read_csv(RAW) if RAW.exists() else download()
    X, y = df.drop(columns="target"), df["target"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, stratify=y, random_state=SEED
    )
    cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
    candidates = {
        "logistic_regression": (
            LogisticRegression(max_iter=2000, random_state=SEED),
            {"model__C": [0.01, 0.1, 1, 10], "model__class_weight": [None, "balanced"]},
        ),
        "random_forest": (
            RandomForestClassifier(random_state=SEED, n_jobs=-1),
            {
                "model__n_estimators": [200, 500],
                "model__max_depth": [None, 5, 10],
                "model__min_samples_leaf": [1, 3],
                "model__class_weight": [None, "balanced"],
            },
        ),
    }

    artifacts = Path("artifacts")
    figures = Path("reports/figures")
    cv_dir = artifacts / "cv_runs"
    artifacts.mkdir(exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)
    cv_dir.mkdir(parents=True, exist_ok=True)

    mlflow.set_tracking_uri(os.getenv("MLFLOW_TRACKING_URI", "mlruns"))
    mlflow.set_experiment("heart-disease-uci")
    leaderboard, fitted = [], {}

    for name, (estimator, parameter_grid) in candidates.items():
        search = GridSearchCV(
            Pipeline([("preprocessing", preprocessing()), ("model", estimator)]),
            parameter_grid,
            scoring="roc_auc",
            cv=cv,
            n_jobs=-1,
            return_train_score=True,
        )
        with mlflow.start_run(run_name=name):
            mlflow.set_tags({"stage": "candidate", "dataset": "UCI Heart Disease", "model": name})
            mlflow.log_params({
                "random_seed": SEED,
                "test_size": 0.20,
                "cv_folds": 5,
                "selection_metric": "roc_auc",
                "numeric_imputation": "median",
                "categorical_imputation": "most_frequent",
            })
            search.fit(X_train, y_train)
            fitted[name] = search.best_estimator_
            mlflow.log_params({key.replace("model__", "best_"): value for key, value in search.best_params_.items()})
            mlflow.log_metrics({
                "cv_best_roc_auc": float(search.best_score_),
                "training_rows": float(len(X_train)),
                "test_rows": float(len(X_test)),
            })

            cv_results_path = cv_dir / f"{name}_cv_results.csv"
            pd.DataFrame(search.cv_results_).to_csv(cv_results_path, index=False)
            mlflow.log_artifact(str(cv_results_path), artifact_path="cross_validation")

            signature = infer_signature(X_train, search.best_estimator_.predict(X_train))
            mlflow.sklearn.log_model(
                search.best_estimator_,
                artifact_path="model",
                signature=signature,
                input_example=X_train.head(3),
            )

        leaderboard.append({"model": name, "cv_roc_auc": search.best_score_, **search.best_params_})

    board = pd.DataFrame(leaderboard).sort_values("cv_roc_auc", ascending=False)
    selected_name = board.iloc[0]["model"]
    selected_model = fitted[selected_name]
    predictions = selected_model.predict(X_test)
    probabilities = selected_model.predict_proba(X_test)[:, 1]
    test_metrics = calculate_metrics(y_test, predictions, probabilities)
    test_metrics.update({
        "selected_model": selected_name,
        "selection_cv_roc_auc": float(board.iloc[0]["cv_roc_auc"]),
        "test_rows": len(y_test),
    })

    model_path = artifacts / "model.joblib"
    metrics_path = artifacts / "metrics.json"
    leaderboard_path = artifacts / "cv_results.csv"
    reference_path = artifacts / "training_reference.csv"
    joblib.dump(selected_model, model_path)
    board.to_csv(leaderboard_path, index=False)
    X_train.assign(target=y_train.values).to_csv(reference_path, index=False)
    metrics_path.write_text(json.dumps(test_metrics, indent=2))
    roc_path, cm_path = save_evaluation_plots(
        y_test, predictions, probabilities, figures
    )

    # A separate final-evaluation run makes model selection and test reporting auditable.
    with mlflow.start_run(run_name="final_model_evaluation"):
        mlflow.set_tags({"stage": "final", "selected_model": selected_name})
        mlflow.log_params({
            "selected_model": selected_name,
            "random_seed": SEED,
            "decision_threshold": 0.5,
            "test_size": 0.20,
            "cv_folds": 5,
        })
        mlflow.log_metrics({key: float(value) for key, value in test_metrics.items() if isinstance(value, (int, float))})
        mlflow.log_artifacts(str(figures), artifact_path="plots")
        mlflow.log_artifact(str(metrics_path), artifact_path="evaluation")
        mlflow.log_artifact(str(leaderboard_path), artifact_path="evaluation")
        signature = infer_signature(X_test, predictions)
        mlflow.sklearn.log_model(
            selected_model,
            artifact_path="model",
            signature=signature,
            input_example=X_test.head(3),
        )

    print(json.dumps(test_metrics, indent=2))


if __name__ == "__main__":
    main()
