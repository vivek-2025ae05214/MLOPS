from pathlib import Path
import json
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from .data import RAW, download

OUT = Path("reports/figures")


def main() -> None:
    df = pd.read_csv(RAW) if RAW.exists() else download()
    OUT.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid")

    numeric = df.select_dtypes("number").columns.drop("target")
    df[numeric].hist(figsize=(16, 12), bins=20)
    plt.tight_layout(); plt.savefig(OUT / "histograms.png", dpi=160); plt.close()

    ax = df["target"].value_counts().sort_index().plot.bar(color=["#4C78A8", "#F58518"])
    ax.set(title="Class balance", xlabel="Heart disease target", ylabel="Rows")
    plt.tight_layout(); plt.savefig(OUT / "class_balance.png", dpi=160); plt.close()

    plt.figure(figsize=(12, 9))
    sns.heatmap(df.corr(numeric_only=True), cmap="vlag", center=0, square=True)
    plt.title("Feature correlation heatmap")
    plt.tight_layout(); plt.savefig(OUT / "correlation_heatmap.png", dpi=160); plt.close()

    summary = {"rows": len(df), "columns": list(df.columns),
               "missing_by_column": df.isna().sum().to_dict(),
               "class_counts": df["target"].value_counts().sort_index().to_dict()}
    Path("reports").mkdir(exist_ok=True)
    Path("reports/eda_summary.json").write_text(json.dumps(summary, indent=2))


if __name__ == "__main__": main()
