from pathlib import Path
import pandas as pd
from ucimlrepo import fetch_ucirepo

RAW = Path("data/raw/heart.csv")
TARGET = "target"


def download() -> pd.DataFrame:
    dataset = fetch_ucirepo(id=45)
    x = dataset.data.features.copy()
    y = dataset.data.targets.copy()
    y_col = y.columns[0]
    df = pd.concat([x, y], axis=1).rename(columns={y_col: TARGET})
    # UCI num is 0 for absence and 1-4 for presence.
    df[TARGET] = (pd.to_numeric(df[TARGET], errors="coerce") > 0).astype(int)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    if df[TARGET].nunique() != 2:
        raise ValueError("Expected a binary target after conversion")
    RAW.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(RAW, index=False)
    return df


if __name__ == "__main__":
    frame = download()
    print(f"Saved {len(frame)} rows and {frame.shape[1]} columns to {RAW}")
