from pydantic import BaseModel, Field

class PatientFeatures(BaseModel):
    age: float = Field(ge=0, le=120)
    sex: int = Field(ge=0, le=1)
    cp: int = Field(ge=0, le=4)
    trestbps: float = Field(gt=0, le=300)
    chol: float = Field(gt=0, le=1000)
    fbs: int = Field(ge=0, le=1)
    restecg: int = Field(ge=0, le=2)
    thalach: float = Field(gt=0, le=300)
    exang: int = Field(ge=0, le=1)
    oldpeak: float = Field(ge=-10, le=20)
    slope: int = Field(ge=0, le=3)
    ca: float = Field(ge=0, le=4)
    thal: float = Field(ge=0, le=7)

class Prediction(BaseModel):
    predicted_class: int
    probability: float
    model_version: str
    warning: str = "Educational output only; not medical advice or a diagnosis."
